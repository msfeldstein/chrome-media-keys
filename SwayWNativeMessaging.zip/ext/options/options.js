(function() {
  var activateText, allSet, attempts, bkg, checkLoginState, checkMediaKeys, deactivateText, focused, mediaKeyTimer, scrobbler;

  bkg = chrome.extension.getBackgroundPage();

  scrobbler = bkg.scrobbler;

  activateText = "Scrobble to Last.fm?";

  deactivateText = "Disable Scrobbling";

  checkLoginState = function() {
    var session;
    session = localStorage.getItem("session");
    document.getElementById("lastfm-enable").innerText = session ? deactivateText : activateText;
    if (session) {
      document.getElementById("lastfm-enable").style.display = "";
      return document.getElementById("lastfm-loading").style.display = "none";
    } else {
      document.getElementById("lastfm-enable").style.display = "";
      return document.getElementById("lastfm-loading").style.display = "none";
    }
  };

  document.getElementById("lastfm-enable").addEventListener('click', function() {
    if (bkg.shouldScrobble()) {
      bkg.setShouldScrobble(false);
      document.getElementById("lastfm-enable").innerText = activateText;
      return;
    }
    document.getElementById("lastfm-enable").innerText = deactivateText;
    bkg.setShouldScrobble(true);
    document.getElementById("lastfm-enable").style.display = "none";
    document.getElementById("lastfm-loading").style.display = "";
    return scrobbler.authenticate(checkLoginState);
  });

  checkLoginState();

  focused = function() {
    return checkLoginState();
  };

  chrome.tabs.getCurrent(function(tab) {
    var currentTabId;
    currentTabId = tab.id;
    return chrome.tabs.onActiveChanged.addListener(function(tabId) {
      if (tabId === currentTabId) {
        return focused();
      }
    });
  });

  allSet = function() {
    var after, before;
    before = document.querySelector("#before");
    before.style.display = "none";
    after = document.querySelector("#after");
    after.style.display = "";
    return document.querySelector(".alert").classList.add("success");
  };

  document.querySelector("#donate-button").addEventListener("click", function() {
    return document.querySelector("#donations").style.display = "block";
  });

  attempts = 0;

  mediaKeyTimer = 0;

  checkMediaKeys = function() {
    var p, timeout;
    if (attempts === 0) {
      document.querySelector(".alert").style.display = "none";
    } else {
      document.querySelector(".alert").style.display = "block";
    }
    attempts = attempts + 1;
    try {
      p = chrome.runtime.connectNative('fm.sway.mediakeys');
      p.onMessage.addListener(function(msg) {
        allSet();
        return clearTimeout(mediaKeyTimer);
      });
    } catch (_error) {
      console.log("noop.");
    }
    timeout = attempts === 0 ? 1 : 1000;
    return mediaKeyTimer = setTimeout(checkMediaKeys, timeout);
  };

  checkMediaKeys();

}).call(this);
