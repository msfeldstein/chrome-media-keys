(function() {
  var p, useMediaKeys;

  p = null;

  useMediaKeys = function() {
    if (p != null) {
      p.sendMessage({
        quit: true
      });
    }
    if (p != null) {
      p.disconnect();
    }
    p = chrome.runtime.connectNative('fm.sway.mediakeys');
    p.onMessage.addListener(function(msg) {
      var action;
      action = msg.action;
      if (action === 'play') {
        return sendAction('pause');
      } else if (action === 'next') {
        return sendAction('next');
      } else if (action === 'back') {
        return sendAction('previous');
      }
    });
    return p.onDisconnect.addListener(function(e) {
      return console.log('Media Keys Disconnected');
    });
  };

  document.addEventListener('DOMContentLoaded', useMediaKeys);

  window.useMediaKeys = useMediaKeys;

}).call(this);
