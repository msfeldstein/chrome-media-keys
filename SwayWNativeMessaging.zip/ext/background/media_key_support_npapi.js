(function() {
  window.useMediaKeys = function() {
    var embed, plugin, pluginHolder;
    pluginHolder = document.getElementById('pluginHolder');
    if (!pluginHolder) {
      pluginHolder = document.createElement('div');
      pluginHolder.id = 'pluginHolder';
      document.body.appendChild(pluginHolder);
    }
    plugin = document.getElementById('pluginId');
    if (plugin) {
      return;
    }
    embed = document.createElement('object');
    embed.type = 'application/x-unitycontrolplugin';
    embed.id = 'pluginId';
    pluginHolder.appendChild(embed);
    plugin = document.getElementById('pluginId');
    plugin.addEventListener('next', function() {
      return sendAction('next');
    });
    plugin.addEventListener('previous', function() {
      return sendAction('previous');
    });
    plugin.addEventListener('playPause', function() {
      return sendAction('pause');
    });
    plugin.addEventListener('voteUp', function() {
      return sendAction('thumbsUp');
    });
    plugin.addEventListener('voteDown', function() {
      return sendAction('thumbsDown');
    });
    plugin.addEventListener('getState', function() {
      return sendAction("getState");
    });
    return window.plugin = plugin;
  };

  document.addEventListener('DOMContentLoaded', window.useMediaKeys);

}).call(this);
